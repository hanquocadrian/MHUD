
package MHUD_BTCN;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class StreamCipherA5 extends javax.swing.JFrame {
    
    private String str_buffered_reader="";
    private static char[] x,y,z;
    private static char[] p, ks, c;
    
//    Method
    private int conv(char n){
        return Integer.parseInt(Character.toString(n));
    }
    
    private char conv(int n){
        return (char)(n+'0');
    }
    
    private boolean GetKey() {
        boolean r = true;
        
        x = jTextX.getText().toCharArray();
        y = jTextY.getText().toCharArray();
        z = jTextZ.getText().toCharArray();
        
        if(x.length!=19||y.length!=22||z.length!=23)
        {
            r= false;
        }        
        return r;
    }
    
    private int Major() {
        int t;
        if(conv(x[8])+conv(y[10])+conv(z[10])>=2)
            t=1;
        else
            t=0;
        return t;
    }
    
    private void XoayX() {
        int x13 = conv(x[13]);
        int x16 = conv(x[16]);
        int x17 = conv(x[17]);
        int x18 = conv(x[18]);
        
        int x0 = (x13+x16+x17+x18)%2;
        for (int i = x.length-1; i > 0; i--) {
            x[i] = x[i-1];
        }
        x[0]=conv(x0);
    }

    private void XoayY() {
        int y20 = conv(y[20]);
        int y21 = conv(y[21]);        
        
        int y0 = (y20+y21)%2;
        for (int i = y.length-1; i > 0; i--) {
            y[i] = y[i-1];
        }
        y[0]=conv(y0);
    }

    private void XoayZ() {
        int z7 = conv(z[7]);
        int z20 = conv(z[20]);
        int z21 = conv(z[21]);
        int z22 = conv(z[22]);
        
        int z0 = (z7+z20+z21+z22)%2;
        for (int i = z.length-1; i > 0; i--) {
            z[i] = z[i-1];
        }
        z[0]=conv(z0);  
    }
    
    private void Algorithm_A5(int count){
        int t;
        for( int i=0; i< count; i++){
            t=Major();
            if(conv(x[8])==t)
                XoayX();
            if(conv(y[10])==t)
                XoayY();
            if(conv(z[10])==t)
                XoayZ();
            //Tính bit sinh ra pos 0
            int x18=conv(x[18]);
            int y21=conv(y[21]);
            int z22=conv(z[22]);
            int bitks = (x18+y21+z22)%2;
            ks[i] = conv(bitks);
        }
    }
    
    private void MaHoa(){
        String s_out="";
        s_out += "P = ";
        for(int i=0;i<p.length;i++)
            s_out += p[i];   
        s_out += "\nK = ";
        for(int i=0;i<ks.length;i++)
            s_out += ks[i];
        
        c = new char[p.length];
        for(int i=0;i<p.length;i++)
        {
            int pi = conv(p[i]);
            int ki = conv(ks[i]);
            c[i] = conv((pi+ki)%2);
        }
        s_out += "\nMã hóa Plaintext:\n=> C = ";
        for(int i=0;i<c.length;i++)
            s_out += c[i];
        
        jTextAreaOutput.setText(s_out);
    }
    
    private  void GiaiMa(){
        String s_out="";
        s_out += "C = ";
        for(int i=0;i<c.length;i++)
            s_out += c[i];   
        s_out += "\nK = ";
        for(int i=0;i<ks.length;i++)
            s_out += ks[i];
        
        p = new char[c.length];
        for(int i=0;i<c.length;i++)
        {
            int ci = conv(c[i]);
            int ki = conv(ks[i]);
            p[i] = conv((ci+ki)%2);
        }
        s_out += "\nGiải mã Ciphertext:\n=> P = ";
        for(int i=0;i<p.length;i++)
            s_out += p[i];
        
        jTextAreaOutput.setText(s_out);
    }
    
    public StreamCipherA5() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaInput = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextAreaOutput = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jTextX = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTextY = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextZ = new javax.swing.JTextField();
        jButtonMaHoa = new javax.swing.JButton();
        jButtonGiaiMa = new javax.swing.JButton();
        jButtonInfo = new javax.swing.JButton();
        jButtonOpenFile = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Stream Cipher with A5/1");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Input", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jTextAreaInput.setColumns(20);
        jTextAreaInput.setRows(5);
        jScrollPane1.setViewportView(jTextAreaInput);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 8, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Output", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jTextAreaOutput.setEditable(false);
        jTextAreaOutput.setColumns(20);
        jTextAreaOutput.setRows(5);
        jScrollPane2.setViewportView(jTextAreaOutput);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 9, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Key", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jLabel1.setText(".");

        jLabel2.setText(".");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextX, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextY, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextZ, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jTextY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jTextZ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButtonMaHoa.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonMaHoa.setText("Mã hóa");
        jButtonMaHoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMaHoaActionPerformed(evt);
            }
        });

        jButtonGiaiMa.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jButtonGiaiMa.setText("Giải mã");
        jButtonGiaiMa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGiaiMaActionPerformed(evt);
            }
        });

        jButtonInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonInfo.setText("?");
        jButtonInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonInfoActionPerformed(evt);
            }
        });

        jButtonOpenFile.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonOpenFile.setText("Open File");
        jButtonOpenFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonOpenFileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButtonOpenFile)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonMaHoa)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButtonGiaiMa)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonInfo))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButtonGiaiMa)
                        .addComponent(jButtonMaHoa)
                        .addComponent(jButtonInfo))
                    .addComponent(jButtonOpenFile))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void jButtonMaHoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMaHoaActionPerformed
        if(jTextAreaInput.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Chưa Input cho Plaintext !","Warning",JOptionPane.WARNING_MESSAGE);
            return;
        }
        else
        {
            p = jTextAreaInput.getText().toCharArray();
            if(GetKey())
            {
                ks = new char[p.length];
                Algorithm_A5(p.length);
                MaHoa();
            }
            else
                JOptionPane.showMessageDialog(null, "Thiếu bit ở key","Warning",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButtonMaHoaActionPerformed

    private void jButtonGiaiMaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGiaiMaActionPerformed
        if(jTextAreaInput.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Chưa Input cho Ciphertext !","Warning",JOptionPane.WARNING_MESSAGE);
            return;
        }
        else
        {
            c = jTextAreaInput.getText().toCharArray();
            if(GetKey())
            {
                ks = new char[c.length];
                Algorithm_A5(c.length);
                GiaiMa();
            }
            else
                JOptionPane.showMessageDialog(null, "Thiếu bit ở key","Warning",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButtonGiaiMaActionPerformed

    private void jButtonOpenFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOpenFileActionPerformed
        JFileChooser jf = new JFileChooser();
        int jfopen = jf.showOpenDialog(null);
        if(jfopen == JFileChooser.APPROVE_OPTION){
            try {
                File f = jf.getSelectedFile();
                FileReader fr = new FileReader(f);
                
                BufferedReader br = new BufferedReader(fr);
                String line;
                while((line = br.readLine()) != null)
                    str_buffered_reader += line+"\n";
                fr.close();
                br.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null,"Lỗi đọc file","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        
        String[] line = str_buffered_reader.split("\n");
        
        int fd = line[0].indexOf(".");
        int ld = line[0].lastIndexOf(".");
        
        String linekey="";
        for(int i=0; i < fd; i++)
            linekey+=line[0].charAt(i);
        jTextX.setText(linekey);
        
        linekey="";
        for(int i= fd+1; i < ld ; i++)
            linekey+=line[0].charAt(i);
        jTextY.setText(linekey);
        
        linekey="";
        for(int i=ld+1; i < line[0].length(); i++)
            linekey+=line[0].charAt(i);
        jTextZ.setText(linekey);
        
        jTextAreaInput.setText(line[1]);
    }//GEN-LAST:event_jButtonOpenFileActionPerformed

    private void jButtonInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonInfoActionPerformed
        String s = "Key: "+"19(bit).22(bit).23(bit)";
        s+= "\n- Lưu ý: Khi sd App vs File, hãy tuân thủ:";
        s+= "\n19(bit).22(bit).23(bit)\nPlaintext(Ciphertext)";
        String stitle = "Hướng dẫn sử dụng";
        JOptionPane.showMessageDialog(null,s, stitle, JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_jButtonInfoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StreamCipherA5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StreamCipherA5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StreamCipherA5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StreamCipherA5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StreamCipherA5().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonGiaiMa;
    private javax.swing.JButton jButtonInfo;
    private javax.swing.JButton jButtonMaHoa;
    private javax.swing.JButton jButtonOpenFile;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextAreaInput;
    private javax.swing.JTextArea jTextAreaOutput;
    private javax.swing.JTextField jTextX;
    private javax.swing.JTextField jTextY;
    private javax.swing.JTextField jTextZ;
    // End of variables declaration//GEN-END:variables

}
