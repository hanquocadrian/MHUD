package MHUD_BTCN;

import java.util.Scanner;

public class CHECK {
    public static String sx="",sy="",sz="";
    public static void main(String[] args) {
//        sp: string plaintext
//        sc: string ciphertext
//        ks: keystream 
//        Major(x1,y3,z3) = t
        String sp = "", key = "";
        String sc = "";
        String ks = "";
        int t=-1;
        
        Scanner datain = new Scanner(System.in);
        System.out.print("Nhap P: ");
        sp = datain.nextLine();
        System.out.print("Nhap K: ");
        key = datain.nextLine();
        
        ChuanHoaKey(key);
        for(int i=0;i<sp.length();i++){
            t=Major();
            if(Integer.parseInt(Character.toString(sx.charAt(1)))==t)
                XoayX();
            if(Integer.parseInt(Character.toString(sy.charAt(3)))==t)
                XoayY();
            if(Integer.parseInt(Character.toString(sz.charAt(3)))==t)
                XoayZ();
            //Tính bit sinh ra pos 0
            int x5=Integer.parseInt(Character.toString(sx.charAt(5)));
            int y7=Integer.parseInt(Character.toString(sy.charAt(7)));
            int z8=Integer.parseInt(Character.toString(sz.charAt(8)));
            int bitks = (x5+y7+z8)%2;
            ks += Integer.toString(bitks);
        }
        System.out.print("\nP = ");
        for(int i=0;i<sp.length();i++)
            System.out.print(sp.charAt(i)+" ");        
        System.out.print("\nK = ");
        for(int i=0;i<ks.length();i++)
            System.out.print(ks.charAt(i)+" ");
        
        for(int i=0;i<sp.length();i++)
        {
            int pi = Integer.parseInt(Character.toString(sp.charAt(i)));
            int ki = Integer.parseInt(Character.toString(ks.charAt(i)));
            sc += Integer.toString((pi+ki)%2);
        }
        System.out.print("\nC = ");
        for(int i=0;i<sc.length();i++)
            System.out.print(sc.charAt(i)+" ");
    }
    private static void ChuanHoaKey(String key) {
        key = key.trim();
        sx += key.substring(0,6);
        sy += key.substring(7,15);
        sz += key.substring(16);
        
//        for(int i=0;i<sz.length();i++)
//            System.out.print(sz.charAt(i)+" ");
    }

    private static int Major() {
        int t=-1;
        int x1=Integer.parseInt(Character.toString(sx.charAt(1)));
        int y3=Integer.parseInt(Character.toString(sy.charAt(3)));
        int z3=Integer.parseInt(Character.toString(sz.charAt(3)));
        
        if(x1+y3+z3>=2)
            t=1;
        else
            t=0;
        return t;
    }

    private static void XoayX() {
        int x2=Integer.parseInt(Character.toString(sx.charAt(2)));
        int x4=Integer.parseInt(Character.toString(sx.charAt(4)));
        int x5=Integer.parseInt(Character.toString(sx.charAt(5)));
        
        int x0 = (x2+x4+x5)%2;
        String sxnew = Integer.toString(x0)+ sx.substring(0,sx.length()-1);
        sx = sxnew;
        
//        System.out.println("");
//        System.out.println("Xoay X: "+sx.length());
//        for(int i=0;i<sx.length();i++)
//            System.out.print(sx.charAt(i)+" ");
    }

    private static void XoayY() {
        int y6=Integer.parseInt(Character.toString(sy.charAt(6)));
        int y7=Integer.parseInt(Character.toString(sy.charAt(7)));        
        
        int y0 = (y6+y7)%2;
        String synew = Integer.toString(y0)+sy.substring(0,sy.length()-1);
        sy= synew;
        
//        System.out.println("");
//        System.out.println("Xoay Y: "+sy.length());
//        for(int i=0;i<sy.length();i++)
//            System.out.print(sy.charAt(i)+" ");
    }

    private static void XoayZ() {
        int z2=Integer.parseInt(Character.toString(sz.charAt(2)));
        int z7=Integer.parseInt(Character.toString(sz.charAt(7)));
        int z8=Integer.parseInt(Character.toString(sz.charAt(8)));
        
        int z0 = (z2+z7+z8)%2;
        String sznew = Integer.toString(z0)+ sz.substring(0,sz.length()-1);
        sz= sznew;     
        
//        System.out.println("");
//        System.out.println("Xoay Z: "+sz.length());
//        for(int i=0;i<sz.length();i++)
//            System.out.print(sz.charAt(i)+" ");
    }
}
